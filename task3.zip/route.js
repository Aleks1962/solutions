
$("#go").click(function(){
	var start = $("#start").val();
	var end = $("#end").val();
	if(start.length == 0 || end.length == 0){
		showMessage("Поле не заполнено");
		//return;
	}
	// start = 'Москва. м.Арбатская';
	// end = 'Москва. м.Третьяковская';

	
	var router = new YMaps.Router([start,  end],[]);
	map.addOverlay(router);
	YMaps.Events.observe(router, router.Events.Success, function () {
	   var route = router.getRoute(0); 
	 		for (var i=0; i < route.getNumRouteSegments(); i++) {//action[]
			  var segment = route.getRouteSegment(i);
			  if(segment.getStreet() != ""){ 
				   var m = '<p>Едем на ' + segment.getStreet() + ', проезжаем ' + segment.getDistance() + ' м.</p>';
				   $("#message").append(m);
			  } 
		}
	   		
	 }); 
	
}); 

var map;
YMaps.jQuery(function () {
	map = new YMaps.Map(YMaps.jQuery("#YMapsID")[0]);
	map.setCenter(new YMaps.GeoPoint(37.64, 55.76), 12);
})